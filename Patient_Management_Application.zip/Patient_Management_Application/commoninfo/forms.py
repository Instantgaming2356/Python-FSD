from django import forms
from .models import UserInfo
 
 
# creating a form
class UserForm(forms.ModelForm):
 
    # create meta class
    class Meta:
        # specify model to be used
        model = UserInfo
 
        # specify fields to be used
        fields = [
            "username",
            "useremail",
            "userpwd",
            "userfname",
            "userlname",
            "userId",
            "userDob"
        ]