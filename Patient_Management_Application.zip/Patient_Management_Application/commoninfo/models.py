from django.db import models

# Create your models here.

class UserInfo(models.Model):
    username = models.CharField(max_length = 200)
    useremail = models.EmailField(max_length = 200)
    userpwd = models.CharField(max_length = 200)
    userfname = models.CharField(max_length = 200)
    userlname = models.CharField(max_length = 200)
    userId = models.CharField(max_length = 200)
    userDob = models.DateField(max_length = 200)

    def __str__(self):
        return self.userId


