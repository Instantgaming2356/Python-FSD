from django.shortcuts import render

# Create your views here.
from .models import UserInfo
from .forms import UserForm

# CommonInfo Front Page
def front_view(request):
    return render(request, "front_view.html")

# Register Patient Details
def register_view(request):
    context ={}
    
    form = UserForm(request.POST or None)
    form.username = request.POST.get('username')
    form.useremail = request.POST.get('useremail')
    form.userpwd = request.POST.get('userpwd')
    if form.userpwd != request.POST.get('userconfpwd'):
        form.userpwd = ''
    form.userfname = request.POST.get('userfname')
    form.userlname = request.POST.get('userlname')
    form.userId = request.POST.get('userId')
    form.userDob = request.POST.get('userDob')
    if form.is_valid():
        msg = 'Succesfully Created'
        context['msg'] = msg
        form.save()
         
    context['form']= form
    return render(request, "register_view.html", context)

def fetch_view(request):
    context ={}
    
    id = request.POST.get('uid')
    #print(id)
    if id:
        # add the dictionary during initialization
        context["data"] = UserInfo.objects.get(userId = id)
         
    return render(request, "fetch_view.html", context)
    #return render(request, "fetch_view.html", {'data':id})
