from django.urls import path, include

from .views import  front_view, register_view, fetch_view

urlpatterns = [
    path('', front_view),
    path('add/', register_view),
    path('fetch/', fetch_view)
]